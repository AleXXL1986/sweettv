import random
from typing import cast

import numpy as np
import pandas as pd
import torch
import tqdm
from pandas import Series
from torch import nn
from torch.utils.data import Dataset, DataLoader

from .swa import SWA
from .utils import get_id_map_serial


class MetaInfo:

    def __init__(self, target_freq_co, target_date_co, extra_fields=None, map_dup_targets=True):
        """

        :param target_freq_co:
        :param target_date_co:
        :param extra_fields:
        """
        self.target_freq_co = target_freq_co
        self.target_date_co = target_date_co
        self.map_dup_targets = map_dup_targets

        self.extra_fields = extra_fields
        if extra_fields is None:
            self.extra_fields = ['genres', 'director', 'actors', 'writers', 'producer']

    def _get_mapped_id(self, x):

        if x in self.id_map:
            return self.id_map[x]
        return x

    def get_mapped_id(self, x):
        return [self._get_mapped_id(k) for k in x]

    def fit(self, data, movies, text_embeddings=None, pairw=None, baseline=None):

        if self.map_dup_targets:
            self.id_map, self.series_list = get_id_map_serial(data, movies)
            self.series_list_set = set(self.series_list.index)
            self.series_raw_list_set = set(self.id_map.index)
        else:
            self.id_map, self.series_list = Series(), Series()
            self.series_list_set, self.series_raw_list_set = set(), set()

        self.text_embeddings = text_embeddings
        self.pairw = pairw
        self.baseline = baseline

        # маппинг фильмов в ид, которые фичи
        features_map = Series(data['movie_id'].unique())
        features_map = features_map.map(self.id_map).fillna(features_map).astype(np.int32).values

        self.features_map = Series(np.arange(features_map.shape[0]), index=features_map)
        # создаем сеты сериалов и фильмов
        self.movies_set = set(data['movie_id'][data['episode_id'] == 0])
        self.serials_set = set(data['movie_id'][data['episode_id'] > 0])

        # маппинг фильмов в ид, которые таргеты
        target_map = data['movie_id'][data['ts'] >= np.datetime64(self.target_date_co)]
        target_map = target_map.map(self.id_map).fillna(target_map).astype(np.int32).value_counts()
        target_map = target_map[target_map > self.target_freq_co]
        target_map = Series(target_map.index)
        self.target_back_map = target_map.reset_index(drop=True)
        self.target_map = Series(np.arange(target_map.shape[0]), index=target_map)

        # собираем размеры эмбеддингов
        self.emb_sizes = {}

        for i in ['genres', 'director', 'actors', 'writers',
                  'music', 'art', 'producer', 'people']:
            self.emb_sizes[i] = movies[i].map(lambda x: 0 if len(x) == 0 else max(x)).max() + 1

        self.emb_sizes['description'] = 768

        # сохраняем инфо о фильмах
        self.movies = movies.copy()
        self.movies['order'] = np.arange(movies.shape[0])
        self.movies['target_avail'] = self.movies['id'].isin(set(self.target_map.index))
        self.movies.set_index('id', inplace=True)

    def get_add_feats_len(self):

        length = 1
        for i in self.extra_fields:
            length += self.emb_sizes[i]

        for _ in ['year', 'imdb_rating', 'tmdb_rating', 'freq']:
            length += 4

        if self.text_embeddings is not None:
            length += self.text_embeddings.shape[1]

        if self.pairw is not None:
            length += self.target_map.shape[0]

        return length

    def get_total_feats_len(self):

        return self.get_add_feats_len() + self.features_map.shape[0]


class TrainDataset(Dataset):

    def __init__(self, movie_ids, movies_meta: MetaInfo, unique_feats=True,
                 factor=4, rates=(0.1, .9), drop_rates=(.1, .3), drop_prob=.5):

        self.movie_ids = movie_ids.map(movies_meta.get_mapped_id).tolist()
        self.movies_meta = movies_meta

        self.unique_feats = unique_feats
        self.factor = factor
        self.rates = rates
        self.drop_rates = drop_rates
        self.drop_prob = drop_prob

    def __len__(self):

        return len(self.movie_ids) * self.factor

    @staticmethod
    def collect_embedding(total_len, idxs, emb=None, mean_pool=False):

        res = np.zeros(total_len, dtype=np.float32)

        flatten_idxs = []
        [flatten_idxs.extend(x) for x in idxs]

        if emb is None:
            np.add.at(res, flatten_idxs, 1)
        else:
            np.add.at(res, (), emb[flatten_idxs].sum(axis=0))

        if mean_pool and len(flatten_idxs) > 0:
            res /= len(flatten_idxs)

        return res

    def collect_add_feats(self, idxs):

        movies_with_info = [x for x in idxs if x in self.movies_meta.movies.index]

        if len(movies_with_info) == 0:
            # if True:
            add_feats = np.zeros(self.movies_meta.get_add_feats_len(), dtype=np.float32)
        else:
            movies_data = self.movies_meta.movies.loc[movies_with_info]

            # create features embedding
            # first - create aggregates on numeric features
            aggs = []
            for func in ['mean', 'min', 'max', 'median']:
                stat = movies_data[['year', 'imdb_rating', 'tmdb_rating', 'freq']].fillna(0).agg(func)
                aggs.append(stat)

            aggs.append(movies_data[['is_serial']].mean())
            aggs = pd.concat(aggs).values

            add_feats = [aggs]
            # collect embedding
            for col in self.movies_meta.extra_fields:
                emb = self.collect_embedding(self.movies_meta.emb_sizes[col], movies_data[col].tolist())
                add_feats.append(emb)

            if self.movies_meta.text_embeddings is not None:
                text_idx = movies_data['order'].map(lambda x: [x]).tolist()
                text_emb = self.collect_embedding(768, text_idx, emb=self.movies_meta.text_embeddings, mean_pool=True)
                add_feats.append(text_emb)

            if self.movies_meta.pairw is not None:
                text_idx = movies_data['order'].map(lambda x: [x]).tolist()
                target_idx = self.movies_meta.target_map.values
                title_emb = self.movies_meta.pairw[text_idx, target_idx].sum(axis=0)
                add_feats.append(title_emb)

            add_feats = np.concatenate(add_feats)

        return add_feats

    def get_colab_feats(self, movies_idx, targets_idx=None):

        target = None
        if targets_idx is not None:
            target = np.zeros(self.movies_meta.target_map.shape[0], dtype=np.float32)
            np.add.at(target,
                      (np.unique(self.movies_meta.target_map.loc[targets_idx].values)),
                      1)

        features = np.zeros(self.movies_meta.features_map.shape[0], dtype=np.float32)

        feats_idx = self.movies_meta.features_map.loc[movies_idx].values
        if self.unique_feats:
            feats_idx = np.unique(feats_idx)
        np.add.at(features, feats_idx, 1)

        return features, target

    def __getitem__(self, idx):

        seed = random.randint(1, 2 ** 32 - 1)
        np.random.seed(seed)

        idx = idx % len(self.movie_ids)

        idxs = np.array(self.movie_ids[idx])
        # check idxs that are ok to return as target
        sl = np.isin(idxs, self.movies_meta.target_map.index)
        mov, target_candidates = idxs[~sl], idxs[sl]

        # random split target candidates
        min_rate, max_rate = self.rates
        np.random.shuffle(target_candidates)
        split_rate = np.random.rand() * (max_rate - min_rate) + min_rate

        target_cnt = int(np.round(split_rate * target_candidates.shape[0], 0))
        target_cnt = min(max(1, target_cnt), target_candidates.shape[0] - 1)

        target_idx, mov_idx = target_candidates[:target_cnt], target_candidates[target_cnt:]
        mov = np.concatenate([mov, mov_idx])

        # augment - drop elements
        if np.random.rand() < self.drop_prob:
            min_rate, max_rate = self.drop_rates
            drop_rate = np.random.rand() * (max_rate - min_rate) + min_rate
            n = int(round(mov.shape[0] * drop_rate, 0))
            if 0 < n < mov.shape[0]:
                drop_sl = np.array([False] * n + [True] * (mov.shape[0] - n))

                np.random.shuffle(drop_sl)
                mov = mov[drop_sl]

        # create base features - colaborative feats
        features, target = self.get_colab_feats(mov, target_idx)

        # extra feats and concat
        add_feats = self.collect_add_feats(mov)

        features = np.concatenate([features, add_feats]).astype(np.float32)
        features = torch.from_numpy(features)
        target = torch.from_numpy(target)

        return features, target


class TestDataset(TrainDataset):

    def __init__(self, movie_ids, movies_meta, unique_feats=True):
        self.movie_ids = movie_ids.map(movies_meta.get_mapped_id).tolist()
        self.movies_meta = movies_meta
        self.unique_feats = unique_feats

    def __len__(self):
        return len(self.movie_ids)

    def __getitem__(self, idx):
        idxs = np.array(self.movie_ids[idx])

        # create base features - colaborative feats
        features, _ = self.get_colab_feats(idxs)

        add_feats = self.collect_add_feats(idxs)
        features = np.concatenate([features, add_feats]).astype(np.float32)

        features = torch.from_numpy(features)

        return features


class FFNet(nn.Module):

    def __init__(self, movies_meta: MetaInfo, embed_size=512, dropout=0.5, ):
        super().__init__()

        input_size = movies_meta.get_total_feats_len()

        self.layer = nn.Linear(input_size, embed_size)
        self.output = nn.Linear(embed_size, movies_meta.target_map.shape[0])

        self.bn = nn.BatchNorm1d(input_size)
        self.dropout = nn.Dropout(dropout)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.bn(x)
        x = self.layer(x)
        x = self.relu(x)
        x = self.dropout(x)
        x = self.output(x)

        return x


# def map5(y_true, y_pred):
#     res = []
#
#     for yt, yp in zip(y_true, y_pred):
#         hit = np.isin(yp, yt)
#         ap = hit.cumsum() / (np.arange(hit.shape[0]) + 1)
#         res.append(ap.mean())
#
#     return np.mean(res)

def map5(y_true, y_pred):
    res = []
    for yt, yp in zip(y_true, y_pred):
        hit = np.isin(yp, yt)
        gtp = max(np.isin(yt, yp).sum(), 1)
        ap = hit.cumsum() * hit / gtp
        res.append(ap.mean())
    return np.mean(res)


class Recommender:
    """
    Превращает индексты классов в ид фильма и выбирает top_n

    """

    def __init__(self, movies_meta: MetaInfo, drop_dup_mov=False, drop_dup_ser=False, top_n=5, n_seasons=2,
                 replace_raw_serials=True, baseline_co=1):

        self.drop_dup_mov = drop_dup_mov
        self.drop_dup_ser = drop_dup_ser
        self.top_n = top_n
        self.movies_meta = movies_meta
        self.n_seasons = n_seasons
        self.replace_raw_serials = replace_raw_serials

        self.baseline_co = baseline_co

    # если есть сериал - получаем список сезонов
    # находим максимальный просмотренный сезон. Рекомендуем

    def get_serials_list(self, old):

        res = []
        if self.n_seasons > 0:
            cnts = Series(old).value_counts()
            old = cnts[cnts > 1].index.values

            set_old = set(old)

            inter = list(set_old.intersection(self.movies_meta.series_raw_list_set))
            unique_serials = np.unique(self.movies_meta.id_map.loc[inter].values)

            for ser in unique_serials:
                ser_list = self.movies_meta.series_list.loc[ser]
                idx = max([n for (n, x) in enumerate(ser_list) if x in set_old])
                seas_left = len(ser_list) - idx
                seas_left = min(seas_left, self.n_seasons)
                for n in range(seas_left):
                    # print(ser_list[idx + n])
                    res.append(ser_list[idx + n])

            if self.replace_raw_serials:
                for i in old:
                    if i in self.movies_meta.serials_set and i not in res and self.n_seasons > 0:
                        res.append(i)

        return res

    def __call__(self, preds, data):

        order = preds.argsort(axis=1)[:, ::-1]
        preds = np.take_along_axis(preds, order, axis=1)

        res = []

        for ps, arr, old in zip(preds, order, data):
            # rec = []
            rec = self.get_serials_list(old)
            # added serials
            added_set = set(self.movies_meta.id_map.loc[[x for x in rec if x in self.movies_meta.id_map.index]])

            orig_len = len(old)
            old = set(old)
            n_base = 0
            for p, val in zip(ps, arr):

                if len(rec) >= self.top_n:
                    break

                val = self.movies_meta.target_back_map[val]

                if self.movies_meta.baseline is not None and orig_len < self.baseline_co:
                    val = self.movies_meta.baseline[n_base]
                    n_base += 1
                    if val in rec or val in old:
                        continue
                    rec.append(val)
                    continue

                # serials handled above
                if val in added_set:
                    continue
                # if serial is recommended and unseen before - switch to the first season
                if val in self.movies_meta.series_list_set:
                    val = self.movies_meta.series_list.loc[val][0]

                if self.drop_dup_mov and val in self.movies_meta.movies_set and val in old:
                    continue

                if self.drop_dup_ser and val in self.movies_meta.serials_set and val in old:
                    continue

                if val not in rec:
                    rec.append(val)

            res.append(rec[:self.top_n])

        return res





def predict_with_models(models, data, recommender: Recommender = None, movies_meta: MetaInfo = None, unique_feats=True):
    if isinstance(models, nn.Module):
        models = [models]

    if movies_meta is None:
        movies_meta = recommender.movies_meta

    test_ds = TestDataset(data, movies_meta, unique_feats)
    test_dl = DataLoader(test_ds, shuffle=False, batch_size=256, num_workers=20)

    preds = []

    for batch in test_dl:
        pred = None
        for model in models:
            model.eval()
            if pred is None:
                pred = model(batch.cuda()).detach().cpu().numpy()
            else:
                pred += model(batch.cuda()).detach().cpu().numpy()
        pred /= len(models)

        preds.append(pred)

    preds = np.concatenate(preds, axis=0)

    if recommender is not None:
        preds = recommender(preds, data)

    return preds


def train_loop(train_dl: DataLoader, n_ep, unique_feats=True, embed_size=512, model=None, swa=None, swa_path=None,
               scores=None,
               **valid_samples):
    movies_meta = cast(TrainDataset, train_dl.dataset).movies_meta

    if type(scores) is dict:
        for k in valid_samples:
            scores[k] = []
    else:
        scores = {x: [] for x in valid_samples}

    if model is None:
        model = FFNet(movies_meta, embed_size=embed_size).cuda()

    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=5e-4)
    if swa is None:
        swa_path = 'temp_swa' if swa_path is None else swa_path
        swa = SWA(10, path=swa_path, weighted=False, rewrite=True)

    recommender = Recommender(movies_meta, drop_dup_mov=True, n_seasons=1)

    for epoch in range(n_ep):

        print('Epoch ', epoch)

        for batch in tqdm.tqdm_notebook(train_dl):
            model.train()
            x, y = batch[0].cuda(), batch[1].cuda()
            optimizer.zero_grad()

            pred = model(x)

            loss = criterion(pred, y)
            loss.backward()
            optimizer.step()

        for k in valid_samples:
            val_pred = predict_with_models(model, valid_samples[k][0], recommender, None, unique_feats)
            val_score = map5(valid_samples[k][1], val_pred)
            print('Score for {0} = {1}'.format(k, val_score))
            scores[k].append(val_score)

        swa.add_checkpoint(model, scores['valid'][-1])

    return model, swa, scores
