import os
import random

import numpy as np
import pandas as pd
import torch


def seed_everything(seed=42):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True


def cut_hist(x, n=15, offset=0):
    last_date = x.max()

    for i in range(offset):
        last_date = last_date - np.timedelta64(n, 'D')
        last_date = x[x <= last_date]
        if len(last_date) == 0:
            return np.zeros(x.shape[0], dtype=bool)

        last_date = last_date.max()

    sl = (x <= last_date) & (x > (last_date - np.timedelta64(n, 'D')))

    return sl  # .values


def get_split_flg(ser, rate=0.2):
    if ser.shape[0] <= 2:
        return np.zeros(ser.shape[0], dtype=bool)

    if (1 / ser.shape[0]) >= rate:
        n = 1
    else:
        n = int(round(rate * ser.shape[0], 0))

    arr = np.array([True] * n + [False] * (ser.shape[0] - n))
    np.random.shuffle(arr)

    return arr


def get_id_map(data, movies):
    movies = movies.copy()

    grp = data.groupby('movie_id')['ts'].max()
    movies['max_time'] = movies['id'].map(grp).fillna(np.datetime64('1990-01-01')).values
    movies.sort_values('max_time', inplace=True)
    movies['new_id'] = movies['id']

    for i in ['imdb_id', 'tmdb_id']:
        imdb_map = movies.drop_duplicates(i, keep='last').set_index(i)['new_id']
        movies['new_id'] = movies[i].map(imdb_map).values

    new_mapping = movies.set_index('id')['new_id']

    return new_mapping


def get_id_map_true_dup(data, movies):
    movies = movies.copy()

    grp = data.groupby('movie_id')['ts'].max()
    movies['max_time'] = movies['id'].map(grp).fillna(np.datetime64('1990-01-01')).values
    movies.sort_values('max_time', inplace=True)
    movies['new_id'] = movies['id']

    for i in ['imdb_id', 'tmdb_id']:
        movies['fake_id'] = movies[i].astype(str) + '_' + movies['year'].astype(str)
        movies_cut = movies[~movies[i].isnull()]

        imdb_map = movies_cut.drop_duplicates('fake_id', keep='last').set_index('fake_id')['new_id']
        movies['new_id'] = movies['fake_id'].map(imdb_map).fillna(movies['new_id']).values.astype(np.int32)

    new_mapping = movies.set_index('id')['new_id']

    return new_mapping


def get_id_map_serial(data, movies):
    movies = movies.copy()

    grp = data.groupby('movie_id')['ts'].max()
    movies['max_time'] = movies['id'].map(grp).fillna(np.datetime64('1990-01-01')).values
    movies.sort_values('max_time', inplace=True)
    movies['new_id'] = movies['id']

    for i in ['imdb_id', 'tmdb_id']:
        movies_cut = movies[~movies[i].isnull()]
        movies_cut = movies_cut[movies_cut.groupby(i)['year'].transform(
            lambda x: [x.value_counts().shape[0] > 1] * x.shape[0]
        )]

        imdb_map = movies_cut.drop_duplicates(i, keep='last').set_index(i)['new_id']
        movies['new_id'] = movies[i].map(imdb_map).fillna(movies['new_id']).values.astype(np.int32)

    movies = movies[movies.groupby('new_id')['id'].transform('count') > 1].sort_values('year')
    new_mapping = movies.set_index('id')['new_id']
    series_list = movies.groupby('new_id')['id'].agg(lambda x: x.tolist())

    return new_mapping, series_list


def correct_movies_id(data, movies):
    data = data.copy()
    new_mapping = get_id_map_true_dup(data, movies)
    data['movie_id'] = data['movie_id'].map(new_mapping).fillna(data['movie_id']).astype(np.int32)

    return data


def get_augmented_data(data_train, window=14, n=20):
    augment = []

    for i in range(1, n):

        aug_data = data_train[data_train.groupby('user_id')['ts'].transform(lambda x: cut_hist(x, window, offset=i))]
        aug_data['user_id'] = aug_data['user_id'].astype(str) + '_' + str(i)
        print(len(aug_data))
        if len(aug_data) == 0:
            break

        augment.append(aug_data)

    augment = pd.concat(augment)

    return augment
